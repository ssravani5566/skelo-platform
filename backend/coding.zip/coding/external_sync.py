import re
from urllib.parse import urljoin

import requests
from bs4 import BeautifulSoup
from django.db import transaction
from django.utils.text import slugify

from .external import build_external_tags, platform_label
from .models import Problem

USER_AGENT = "SCOTT-Coding-Catalog/1.0 (+student-platform-integration)"


def _session():
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT, "Accept-Language": "en-US,en;q=0.9"})
    return s


def _difficulty(value):
    value = str(value or "").upper()
    if value in {"1", "EASY", "BEGINNER"}:
        return "EASY"
    if value in {"2", "MEDIUM", "INTERMEDIATE"}:
        return "MEDIUM"
    if value in {"3", "HARD", "ADVANCED", "EXPERT"}:
        return "HARD"
    return "MEDIUM"


def _upsert(item):
    platform = item["platform"]
    external_id = str(item.get("external_id") or "").strip()
    url = item["url"]
    tags = build_external_tags(
        platform,
        url,
        external_id,
        item.get("tags"),
        number=item.get("number"),
        acceptance=item.get("acceptance"),
        success_rate=item.get("success_rate"),
        premium=item.get("premium"),
        topics=item.get("topics"),
        score=item.get("score"),
    )
    slug_base = slugify(f"{platform}-{external_id or item['title']}")[:230] or "external-problem"
    obj = Problem.objects.filter(slug=slug_base).first()
    if obj is None:
        slug = slug_base
        suffix = 2
        while Problem.objects.filter(slug=slug).exists():
            slug = f"{slug_base[:220]}-{suffix}"
            suffix += 1
        obj = Problem(slug=slug)
    obj.title = item["title"][:200]
    obj.description = item.get("description") or f"Open this {platform_label(platform)} problem on the original platform to read the full statement and solve it."
    obj.input_format = ""
    obj.output_format = ""
    obj.constraints = ""
    obj.difficulty = _difficulty(item.get("difficulty"))
    obj.topic = (item.get("topic") or "Coding")[:100]
    obj.tags = tags
    obj.points = 0
    obj.is_published = True
    obj.save()
    return obj


def sync_leetcode(limit=5000):
    """
    Import real LeetCode problem metadata and save it to PostgreSQL.

    The actual question remains on LeetCode.
    SCOTT stores only:
      - title
      - question number
      - difficulty
      - acceptance
      - premium flag
      - official LeetCode URL
    """

    s = _session()

    # Primary source: LeetCode's public problem-set endpoint.
    try:
        response = s.get(
            "https://leetcode.com/api/problems/all/",
            timeout=30,
            headers={
                "User-Agent": USER_AGENT,
                "Accept": "application/json,text/plain,*/*",
                "Referer": "https://leetcode.com/problemset/all/",
            },
        )

        response.raise_for_status()

        payload = response.json()
        pairs = payload.get("stat_status_pairs") or []

    except Exception:
        pairs = []

    # Fallback source:
    # public LeetCode catalog API which exposes problem metadata.
    if not pairs:
        try:
            response = s.get(
                "https://alfa-leetcode-api.onrender.com/problems",
                params={
                    "limit": min(int(limit), 5000),
                },
                timeout=45,
            )

            response.raise_for_status()

            payload = response.json()

            pairs = payload.get("problemsetQuestionList") or payload.get(
                "problems"
            ) or payload.get("data") or []

        except Exception as exc:
            raise RuntimeError(
                "Unable to load the LeetCode problem catalog. "
                f"Official endpoint and fallback endpoint failed: {exc}"
            )

    if not pairs:
        raise RuntimeError(
            "No LeetCode problems were returned by the catalog sources."
        )

    count = 0

    with transaction.atomic():

        for item in pairs:

            if count >= min(int(limit), 5000):
                break

            # -----------------------------
            # Format 1:
            # LeetCode stat_status_pairs
            # -----------------------------
            stat = item.get("stat") or {}

            title = str(
                stat.get("question__title")
                or ""
            ).strip()

            slug = str(
                stat.get("question__title_slug")
                or ""
            ).strip()

            question_number = str(
                stat.get("frontend_question_id")
                or stat.get("question_id")
                or ""
            ).strip()

            difficulty_level = (
                (item.get("difficulty") or {}).get("level")
            )

            premium = bool(
                item.get("paid_only")
                or item.get("isPaidOnly")
            )

            acceptance = None

            total_accepted = stat.get("total_acs")
            total_submitted = stat.get("total_submitted")

            if total_accepted is not None and total_submitted:
                try:
                    acceptance = round(
                        float(total_accepted)
                        / float(total_submitted)
                        * 100,
                        2,
                    )
                except (TypeError, ValueError, ZeroDivisionError):
                    acceptance = None

            # -----------------------------
            # Format 2:
            # alfa-leetcode-api
            # -----------------------------
            if not title:
                title = str(
                    item.get("title")
                    or item.get("name")
                    or ""
                ).strip()

            if not slug:
                slug = str(
                    item.get("titleSlug")
                    or item.get("title_slug")
                    or item.get("slug")
                    or ""
                ).strip()

            if not question_number:
                question_number = str(
                    item.get("questionFrontendId")
                    or item.get("frontendQuestionId")
                    or item.get("questionId")
                    or item.get("id")
                    or ""
                ).strip()

            if difficulty_level is None:
                difficulty_value = (
                    item.get("difficulty")
                    or item.get("difficulty_name")
                    or ""
                )
            else:
                difficulty_value = difficulty_level

            difficulty = _difficulty(difficulty_value)

            if acceptance is None:
                raw_acceptance = (
                    item.get("acRate")
                    or item.get("acceptance_rate")
                    or item.get("acceptance")
                )

                try:
                    acceptance = (
                        float(raw_acceptance)
                        if raw_acceptance not in (None, "")
                        else None
                    )
                except (TypeError, ValueError):
                    acceptance = None

            if not title or not slug:
                continue

            url = f"https://leetcode.com/problems/{slug}/"

            _upsert(
                {
                    "platform": "LEETCODE",
                    "external_id": question_number or slug,
                    "number": question_number,
                    "title": title,
                    "difficulty": difficulty,
                    "acceptance": acceptance,
                    "premium": premium,
                    "topic": "Algorithms",
                    "url": url,
                }
            )

            count += 1

    if count == 0:
        raise RuntimeError(
            "LeetCode catalog was reached, but no usable questions were imported."
        )

    return count
def sync_codeforces(limit=5000):
    s = _session()
    response = s.get("https://codeforces.com/api/problemset.problems", timeout=25)
    response.raise_for_status()
    payload = response.json()
    if payload.get("status") != "OK":
        raise RuntimeError("Codeforces returned an unsuccessful API response.")
    problems = payload.get("result", {}).get("problems", [])
    stats = payload.get("result", {}).get("problemStatistics", [])
    solved_by_key = {f"{x.get('contestId')}-{x.get('index')}": x.get("solvedCount", 0) for x in stats}
    count = 0
    with transaction.atomic():
        for p in problems[:limit]:
            cid, index = p.get("contestId"), p.get("index")
            if cid is None or not index or not p.get("name"):
                continue
            rating = p.get("rating") or 0
            difficulty = "EASY" if rating < 1300 else "MEDIUM" if rating < 1900 else "HARD"
            tags = p.get("tags") or []
            _upsert({
                "platform": "CODEFORCES", "external_id": f"{cid}-{index}", "number": f"{cid}{index}",
                "title": p["name"], "difficulty": difficulty,
                "topic": tags[0] if tags else "Algorithms", "tags": tags[:12],
                "score": solved_by_key.get(f"{cid}-{index}", 0),
                "url": f"https://codeforces.com/problemset/problem/{cid}/{index}",
            })
            count += 1
    return count


def _scrape_challenge_pages(platform, base_url, href_pattern, limit=500):
    s = _session()
    response = s.get(base_url, timeout=25)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    seen = set()
    count = 0
    with transaction.atomic():
        for a in soup.find_all("a", href=True):
            href = a.get("href", "")
            if not re.search(href_pattern, href):
                continue
            title = " ".join(a.get_text(" ", strip=True).split())
            if not title or href in seen or len(title) < 2:
                continue
            seen.add(href)
            url = urljoin(base_url, href)
            external_id = href.rstrip("/").split("/")[-1]
            _upsert({
                "platform": platform, "external_id": external_id,
                "title": title, "difficulty": "MEDIUM", "topic": "Coding",
                "url": url,
            })
            count += 1
            if count >= limit:
                break
    return count


def sync_hackerrank(limit=500):
    return _scrape_challenge_pages("HACKERRANK", "https://www.hackerrank.com/domains/algorithms", r"/challenges/[^/?#]+/?$", limit)


def sync_codechef(limit=500):
    return _scrape_challenge_pages("CODECHEF", "https://www.codechef.com/practice", r"/problems/[A-Za-z0-9_-]+/?$", limit)


def sync_platform(platform, limit=5000):
    if platform == "LEETCODE":
        return sync_leetcode(limit)
    if platform == "CODEFORCES":
        return sync_codeforces(limit)
    if platform == "HACKERRANK":
        return sync_hackerrank(min(limit, 1000))
    if platform == "CODECHEF":
        return sync_codechef(min(limit, 1000))
    if platform == "GEEKSFORGEEKS":
        raise RuntimeError("GeeksforGeeks live catalog sync is not enabled. Add approved question links through Management → External Coding.")
    raise RuntimeError("Unsupported platform.")
