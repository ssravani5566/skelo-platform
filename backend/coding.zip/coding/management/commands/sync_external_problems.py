from django.core.management.base import BaseCommand, CommandError
from coding.external_sync import sync_platform
from coding.external import PLATFORM_CHOICES


class Command(BaseCommand):
    help = "Sync real public coding-question metadata into SCOTT and retain links to the original platform."

    def add_arguments(self, parser):
        parser.add_argument("--platform", choices=[x[0] for x in PLATFORM_CHOICES], required=True)
        parser.add_argument("--limit", type=int, default=5000)

    def handle(self, *args, **options):
        platform = options["platform"]
        limit = max(1, min(options["limit"], 5000))
        try:
            count = sync_platform(platform, limit)
        except Exception as exc:
            raise CommandError(str(exc)) from exc
        self.stdout.write(self.style.SUCCESS(f"Synced {count} real {platform} questions."))
