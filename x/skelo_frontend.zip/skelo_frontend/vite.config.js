import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
export default defineConfig({
  plugins:[react()],
  server:{port:5173,host:"0.0.0.0",proxy:{"/api":{target:process.env.VITE_DEV_API_TARGET||"http://127.0.0.1:8000",changeOrigin:true}}},
  preview:{host:"0.0.0.0",port:4173},
});
